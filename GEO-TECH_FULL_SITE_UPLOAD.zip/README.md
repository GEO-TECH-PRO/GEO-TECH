# GEO-TECH Static Website (GitHub Pages)

## Upload
Upload everything to your GitHub repo root.
Settings → Pages → Deploy from a branch → main / (root).

## Update
Edit: assets/config.json
Replace images:
- assets/images/logo.png
- assets/images/about.jpg
